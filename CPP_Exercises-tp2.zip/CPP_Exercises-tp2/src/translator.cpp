#include <iostream>

int main()
{
    while (true)
    {
        std::cout << "This is a translator, but it does nothing for now..." << std::endl;
        std::cin.ignore();
    }

    return 0;
}